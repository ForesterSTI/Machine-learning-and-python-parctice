#import libraries
import numpy as np
import pandas as pd
import matplotlib.pyplot as pl
import seaborn as sn
from skimpy import clean_columns
import plotly.express as px

#load raw data
raw = pd.read_csv("Day 4 data_cleanup/Data/raw_data.csv")
meta = pd.read_csv("Day 4 data_cleanup/Data/metadata.csv")
#isolate Coapplicant income table and Loan_Status
#Key details about given data
#-No missing null data
#data has over 300 duplicaate instances 
df = raw[['CoapplicantIncome']]
test = df.select_dtypes("number").nunique()
#make column for box plot
column = ['CoapplicantIncome']


#Plot features 
pl.figure(figsize=(4,5))
for cal in column: 
    fig = px.box(data_frame=df[column], x=cal, color=raw['Loan_Status'], title=f'BoxPlot for {cal} Feature against the Target')
    fig.update_layout(xaxis_title =f'{cal} feature')
    fig.show()
''' 
#Creating seporate data frame with onlu Loan ID and Co application data 
Appincome = raw[['CoapplicantIncome']]
#Appincome = raw[['Loan_ID','CoapplicantIncome']] ignore for now 
#isolating and removing dublicates 


Duplicates = Appincome.duplicated()
cleaning_data = Duplicates.drop_duplicates()
Cleaned = Appincome(cleaning_data.groupby('CoapplicantIncome').agg({'Income':'mean'}).reset_index())
#creating data field with clean data
print(cleaning_data)

FAILED/GOT STUCK
'''
'''
#what data should look luke i think but its not cleaned
Q1 = Appincome.quantile(0.25)
Q2 = Appincome.quantile(0.5)
Q3 = Appincome.quantile(0.75)
#Calculating inter quartile range
IQR = Q3-Q1
#Calculate bounds 
Lower_bound = Q1-1.5*IQR
Upper_bound = Q3+1.5*IQR

#isolate the outliers
outliers = (Appincome < Lower_bound) | (Appincome > Upper_bound)


pl.figure(figsize=(8,8))
pl.boxplot(Appincome, vert=False)

# np.ones_like(cleaned_loan_amounts[outliers]) creates the an array one 1s
#with the same shape as cleaned_loan_amounts[outliers]
pl.scatter(Appincome[outliers], np.ones_like(Appincome[outliers])
            , color='blue', label='Outliers')
pl.title('Distribution of Loan amounts')
pl.xlabel("Loan amounts") 
'''
'''
pl.legend(labels=[f"Total number of values: {len(raw_data['LoanAmount'])}\n"
                   f"Total number of usuable data: {len(raw_data['LoanAmount'])-missing_values_of_LoanAmount}\n"
                   f"Total number of missing values: {missing_values_of_LoanAmount}\n"
                   f"Total number of outliers: {outliers.sum()}\n"
                   f"Percentage of missing values: {percentage_of_missing_values:.2f}%"], loc='upper right', facecolor=None) 
                   
                 
pl.show()
'''
'''
'''